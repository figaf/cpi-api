package figaf.pitocpi3;

import com.sap.aii.mapping.api.*;
import com.sap.aii.mapping.lookup.*;
import com.sap.aii.mappingtool.tf7.rt.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import com.sap.aii.mappingtool.functionlibrary.*;

public class InvoiceAdd extends AFunctionLibrary {

    @Init
    public void init(GlobalContainer container) throws StreamTransformationException {
    }

    @CleanUp
    public void cleanUp(GlobalContainer container) throws StreamTransformationException {
    }

    //The key property of the UDFs should not be changed. If it is changed it cannot be used
    //in the Message Mappings which are imported from ESR system.
    @FunctionLibraryMethod(category = "InvoiceAdd", title = "AddZeroTitle", executionType = "SINGLE_VALUE", key = "4d4f3039-be60-11eb-c990-00090faa0001")
    public String AddZero(@UDFParam(paramCategory = "Argument", title = "") String number, Container container) throws StreamTransformationException {
        int m = 17;
        int testtt = 10;
        return "000" + number;
    }

    @FunctionLibraryMethod(category = "InvoiceAdd", title = "usedTime2", executionType = "ALL_VALUES_OF_CONTEXT", key = "cc51a87b-bebb-11eb-9218-00090faa0001")
    public void usedTime(@UDFParam(paramCategory = "Argument", title = "") String[] var1, @UDFParam(paramCategory = "ResultList", title = "") ResultList result, Container container) throws StreamTransformationException {
        int i = 1;
        for (String string : var1) {
            result.addValue(string + " " + i);
            i++;
        }
    }
}
